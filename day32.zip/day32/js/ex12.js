﻿function fun() {

    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;
    fullname = fname + " " + lname;

    var ul = document.getElementById("mylist");
    var li = document.createElement("li");
    var text = document.createTextNode(fullname);
    li.appendChild(text);
    ul.appendChild(li)

}