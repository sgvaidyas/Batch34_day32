﻿function add() {
    var a = prompt("Enter val of a = ")
    var b = prompt("Enter val of b = ")
    document.write("A = " + a + "<br>")
    document.write("B = " + b + "<br>")
    sum = parseInt(a) + parseInt(b)
    document.write("A+B = " + sum + "<br>")
}

function sub(a, b) {
    diff = a - b;
    document.write("A-B = " + diff + "<br>")
}
function mul(a, b) {
    return a * b;
}
