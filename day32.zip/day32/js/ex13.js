﻿function cal() {

    var m1 = document.getElementById("m1").value;
    var m2 = document.getElementById("m2").value;

    total = parseInt(m1) + parseInt(m2);
    aver = total / 2;
    document.getElementById("total").innerHTML = "TOTAL = " + total;
    document.getElementById("average").innerHTML = "AVERAGE = " + aver;


}